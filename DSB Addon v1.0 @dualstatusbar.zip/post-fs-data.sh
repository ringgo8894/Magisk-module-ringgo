#!/system/bin/sh
MODULE=/data/adb/modules