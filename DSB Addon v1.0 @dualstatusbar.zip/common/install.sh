#!/system/bin/sh
DSB=$MODPATH/system
VARS() {
SOC=$(getprop ro.board.platform)
}